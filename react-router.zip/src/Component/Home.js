import React from "react";

const Home = () =>{
    return(
        <div className='ui raised very padded text container segment' style={{marginTop:'80px'}}>
            <h3 className='ui header'>Home</h3>
            <p>The "layout route" is a shared component that inserts common content on all pages, such as a navigation menu.</p>
        </div>
    )
}
export default Home