# React Router Practice 

This Project Will give you a clear understanding on how to use the React router in your own projects.

I have created this project for practising the new React Router.

If you find some issue in this you can raise a issue and we can solve that or we can Improve the code.

## React Router

React Router is a powerful library that allows you to define routes in your React application. With React Router, you can easily map URLs to different parts of your application, allowing you to create a more dynamic and interactive user experience.

1. Routeing.

2. Nested Routing.

3. Dynamic Routing.

This All I have tried and practiced. I will update this repository after I tried more of the other features available in the react Router Library.
