import React from 'react'

const ContactSearch = () => {
  return (
    <div className='ContactHeading'>ContactSearch</div>
  )
}

export default ContactSearch