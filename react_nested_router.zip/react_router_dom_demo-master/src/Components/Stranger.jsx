import React from 'react'

const Stranger = () => {
  return <div className="ContactHeading">Stranger</div>;
}

export default Stranger