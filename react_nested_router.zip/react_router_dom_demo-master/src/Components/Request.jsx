import React from 'react'

const Request = () => {
  return <div className="ContactHeading">Request</div>;
}

export default Request