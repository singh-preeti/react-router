import React from 'react'

const Friends = () => {
  return <div className="ContactHeading">Friends</div>;
}

export default Friends